const functions = require('@google-cloud/functions-framework');

functions.http('animalsss', (_req, res) => {
  const dogInfo = {
    images: [
      "https://www.patasdacasa.com.br/sites/default/files/images-carrossel/1295-a-vira-lata-caramelo-de-livia-ja-foi-mui-orig-3.webp",
      "https://www.patasdacasa.com.br/sites/default/files/images-carrossel/1292-o-vira-lata-caramelo-e-conhecido-pelo-ca-orig-5.webp"
    ],
    name: "Pipoquinha do Sul",
    age: "8 anos",
    breed: "Cadela caramelo",
    description: "Pipoquinha, uma cadelinha caramelo adorável e muito querida, desapareceu na Av. Litorânea, no bairro Calhau, em São Luís - MA (CEP: 65076-641). Ela é dócil, amorosa e faz muita falta para sua família.\n\nEstamos oferecendo uma recompensa de R$ 5.000,00 para quem tiver informações que ajudem a encontrá-la. Qualquer notícia sobre Pipoquinha será muito bem-vinda! Por favor, ajude compartilhando.",
    contact: "(98)999999999",
    email: "encontreapipoquinha@example.com"
  };

  // HTML
  const htmlResponse = `
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Procura-se</title>
      <style>
        body { font-family: Arial, sans-serif; text-align: center; }
        .dog-info { margin-top: 20px; text-align: left; display: inline-block; max-width: 400px; }
        .images { display: flex; justify-content: center; gap: 10px; }
        .images img { max-width: 200px; border-radius: 5px; }
        h1 { font-size: 24px; color: red; }
        p { text-align: justify; }
      </style>
    </head>
    <body>
      <h1>Procura-se</h1>
      <div class="dog-info">
        <div class="images">
          <img src="${dogInfo.images[0]}" alt="Imagem do cachorro ${dogInfo.name} 1">
          <img src="${dogInfo.images[1]}" alt="Imagem do cachorro ${dogInfo.name} 2">
        </div>
        <h2 style="text-align: center;">${dogInfo.name}</h2>
        <p><strong>Idade:</strong> ${dogInfo.age}</p>
        <p><strong>Raça:</strong> ${dogInfo.breed}</p>
        <p><strong>Descrição:</strong> ${dogInfo.description}</p>
        <p><strong>Contato:</strong> ${dogInfo.contact}</p>
        <p><strong>E-mail:</strong> <a href="mailto:${dogInfo.email}">${dogInfo.email}</a></p>
      </div>
    </body>
    </html>
  `;

  res.send(htmlResponse);
});
